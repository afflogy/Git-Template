---
name: "\U0001F9EA Testing"
about: 테스트 작성을 진행합니다.
title: "[\U0001F9EA TEST]"
labels: "\U0001F9EA TEST"
assignees: ''

---

## 🧪 테스트 내용

- 테스트 하고자 하는 내용에 대해서 알려주세요!